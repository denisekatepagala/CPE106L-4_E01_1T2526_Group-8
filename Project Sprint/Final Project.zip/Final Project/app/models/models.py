from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field, Relationship


class User(SQLModel, table=True):
    user_id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str
    phone: Optional[str] = None
    priority_level: int = 0
    created_at: datetime = Field(default_factory=datetime.utcnow)

    ride_requests: list["RideRequest"] = Relationship(back_populates="user")


class Driver(SQLModel, table=True):
    driver_id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    phone: Optional[str] = None
    vehicle_type: str
    plate_number: str
    availability_status: str = "available"

    ride_requests: list["RideRequest"] = Relationship(back_populates="driver")


class RideRequest(SQLModel, table=True):
    ride_id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.user_id")
    driver_id: Optional[int] = Field(default=None, foreign_key="driver.driver_id")
    pickup_location: str
    dropoff_location: str
    status: str = "requested"
    requested_at: datetime = Field(default_factory=datetime.utcnow)
    scheduled_for: Optional[datetime] = None
    estimated_distance: Optional[float] = None
    estimated_duration: Optional[int] = None

    user: Optional[User] = Relationship(back_populates="ride_requests")
    driver: Optional[Driver] = Relationship(back_populates="ride_requests")
