from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.database import engine
from app.models.models import Driver

router = APIRouter(prefix="/drivers", tags=["Drivers"])

def get_session():
    with Session(engine) as session:
        yield session

@router.post("/", response_model=Driver)
def create_driver(driver: Driver, session: Session = Depends(get_session)):
    session.add(driver)
    session.commit()
    session.refresh(driver)
    return driver

@router.get("/", response_model=list[Driver])
def get_drivers(session: Session = Depends(get_session)):
    return session.exec(select(Driver)).all()

@router.get("/{driver_id}", response_model=Driver)
def get_driver(driver_id: int, session: Session = Depends(get_session)):
    driver = session.get(Driver, driver_id)
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")
    return driver

@router.put("/{driver_id}", response_model=Driver)
def update_driver(driver_id: int, updated: Driver, session: Session = Depends(get_session)):
    driver = session.get(Driver, driver_id)
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")
    for k, v in updated.dict(exclude_unset=True).items():
        setattr(driver, k, v)
    session.add(driver)
    session.commit()
    session.refresh(driver)
    return driver

@router.delete("/{driver_id}")
def delete_driver(driver_id: int, session: Session = Depends(get_session)):
    driver = session.get(Driver, driver_id)
    if not driver:
        raise HTTPException(status_code=404, detail="Driver not found")
    session.delete(driver)
    session.commit()
    return {"message": "Driver deleted"}
