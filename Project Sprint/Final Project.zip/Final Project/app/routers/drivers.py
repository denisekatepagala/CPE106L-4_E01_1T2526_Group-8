from fastapi import APIRouter

router = APIRouter(prefix="/drivers", tags=["Drivers"])

@router.get("/")
def read_drivers():
    return {"message": "Drivers endpoint placeholder"}
