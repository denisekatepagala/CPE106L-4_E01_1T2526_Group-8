from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select
from app.database import engine
from app.models.models import RideRequest

router = APIRouter(prefix="/ride-requests", tags=["Ride Requests"])

def get_session():
    with Session(engine) as session:
        yield session

@router.post("/", response_model=RideRequest)
def create_ride_request(ride: RideRequest, session: Session = Depends(get_session)):
    session.add(ride)
    session.commit()
    session.refresh(ride)
    return ride

@router.get("/", response_model=list[RideRequest])
def get_ride_requests(session: Session = Depends(get_session)):
    return session.exec(select(RideRequest)).all()

@router.get("/{ride_id}", response_model=RideRequest)
def get_ride_request(ride_id: int, session: Session = Depends(get_session)):
    r = session.get(RideRequest, ride_id)
    if not r:
        raise HTTPException(status_code=404, detail="RideRequest not found")
    return r

@router.put("/{ride_id}", response_model=RideRequest)
def update_ride_request(ride_id: int, updated: RideRequest, session: Session = Depends(get_session)):
    r = session.get(RideRequest, ride_id)
    if not r:
        raise HTTPException(status_code=404, detail="RideRequest not found")
    for k, v in updated.dict(exclude_unset=True).items():
        setattr(r, k, v)
    session.add(r)
    session.commit()
    session.refresh(r)
    return r

@router.delete("/{ride_id}")
def delete_ride_request(ride_id: int, session: Session = Depends(get_session)):
    r = session.get(RideRequest, ride_id)
    if not r:
        raise HTTPException(status_code=404, detail="RideRequest not found")
    session.delete(r)
    session.commit()
    return {"message": "RideRequest deleted"}
