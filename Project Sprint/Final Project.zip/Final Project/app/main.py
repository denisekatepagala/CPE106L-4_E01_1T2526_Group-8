from fastapi import FastAPI
from app.database import init_db
from app.routers import users, drivers, ride_requests

app = FastAPI(title="Accessible Transport Scheduler")

@app.on_event("startup")
def on_startup():
    init_db()

app.include_router(users.router)
app.include_router(drivers.router)
app.include_router(ride_requests.router)
